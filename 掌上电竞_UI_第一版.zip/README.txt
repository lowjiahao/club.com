掌上电竞 UI 第一版

文件：
login.html      登录
register.html   注册
index.html      首页 + 护航专区 + 加购物车
order.html      结算页面（这里填写游戏、UID、区服、护航内容）
orders.html     我的订单 UI
profile.html    个人中心 UI
style.css       公共样式

使用：
1. 把整个文件夹上传/复制到 Acode。
2. 打开 login.html。
3. 登录按钮目前只是跳转到首页。
4. 点击护航专区商品的 + 加入购物车。
5. 点击去结算，在 order.html 填写游戏信息。
6. 目前没有 Firebase、支付和真实订单。
